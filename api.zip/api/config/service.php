<?php

define('DB_SERVERNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'cpe@rmuti1234');
define('DB_NAME', 'dormitory');
define('JWT_KEY', 'dormitory_cpe@rmuti1234');
